package com.example.kursishi.data.models

class IntoData (
    val title:String,
    val imageIrl:Int,
    val color:Int
)