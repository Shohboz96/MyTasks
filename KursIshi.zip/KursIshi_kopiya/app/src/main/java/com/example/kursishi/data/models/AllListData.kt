package com.example.kursishi.data.models

data class AllListData(val list: List<TaskData>)