package com.example.kursishi.ui.screens

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.widget.Toolbar
import com.example.kursishi.R
import com.example.kursishi.util.extensions.toDatetime
import kotlinx.android.synthetic.main.activity_show.*
import java.util.*

class ShowActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show)
        val toolbar: Toolbar = findViewById(R.id.toolbar_detals)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        val bundle = intent.extras!!

        val now = Calendar.getInstance().timeInMillis
        val time = bundle.getLong("deadline")
        detalsTimeTask.text = time.toDatetime()
        detalsNameTask.text = bundle.getString("name")
        detalsUrgancyTask.text = bundle.getString("urgancy")
        detalsHashTagTask.text = bundle.getString("hashtag")
        detalsTextTask.text = bundle.getString("text")

        coutdownView.start(time - now)
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) finish()
        return super.onOptionsItemSelected(item)

    }
}
