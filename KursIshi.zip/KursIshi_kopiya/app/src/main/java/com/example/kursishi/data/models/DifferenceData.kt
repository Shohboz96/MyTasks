package com.example.kursishi.data.models

data class DifferenceData(val days: Int, val hours: Int, val min: Int, val sec: Int)