package com.example.kursishi.util

typealias SingleBlock <T> = (T) -> Unit
