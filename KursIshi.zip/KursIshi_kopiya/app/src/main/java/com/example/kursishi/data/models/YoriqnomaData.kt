package com.example.kursishi.data.models

data class YoriqnomaData(
    val imageUrl:Int,
    val yoriqnomaText:String
)